/*
	@Project: Line zapper
	@Function: SPI setup and reader
	@Autor: Martin Lund Djurhuus
	@Universty: Technical University of Denmark - DTU
	@Date: 18 January 2017
*/

#include "SPI.h"

#if !defined(SPI_HEADER)

#include "xil_types.h"
#include "xparameters.h"
#include <stdio.h>
#include "xspips.h"
#include "xplatform_info.h"
#include "xil_printf.h"

#endif

static XSpiPs SpiInstance;
XSpiPs *SpiPTR;
XSpiPs_Config *SpiConfig;

u8 readBuffer[4];
u8 writeBuffer[4];


void SPI_setup() {
	//Konfiger SPI ud fra device ID
	SpiConfig = XSpiPs_LookupConfig(SPI_DEVICE_ID);
	if (NULL == SpiConfig) {
		printf("Error Look up \n\r");
		return XST_FAILURE;
	}

	//initialize SPI udfra konfigerstinonerne
	int Status = XSpiPs_CfgInitialize(&SpiInstance, SpiConfig, SpiConfig->BaseAddress);
	if (Status != XST_SUCCESS) {
		printf("Error INITIALIZE \n\r");
		return XST_FAILURE;
	}

	//Perform a self-test to check hardware build
	Status = XSpiPs_SelfTest(&SpiInstance);
	if (Status != XST_SUCCESS) {
		printf("Error Self Test \n\r");
		return XST_FAILURE;
	}

	/*
	 * Set the SPI device as a master with manual start and manual
	 * chip select mode options
	 */
	XSpiPs_SetOptions(&SpiInstance, XSPIPS_MANUAL_START_OPTION | \
			XSPIPS_MASTER_OPTION | XSPIPS_FORCE_SSELECT_OPTION);

	/*
	 * Set the SPI device pre-scalar to divide by 128
	 */
	XSpiPs_SetClkPrescaler(&SpiInstance, XSPIPS_CLK_PRESCALE_128);

	//set alt, i begge buffer, til at være nul
	memset(writeBuffer, 0x00, sizeof(writeBuffer));
	memset(readBuffer, 0x00, sizeof(readBuffer));

	//Vælger slave
	XSpiPs_SetSlaveSelect(&SpiInstance, 0);


	return XST_SUCCESS;
}

int SPI_read(int pin) {
	
	if(pin < 0 || pin > 7){
		return -1;
	}
	
	/*
	 * for at sende skal man bruge 2 bits
	 * spi tage 3 bits se data blad for mcp3008 side 21
	 *
	 */
	writeBuffer[0] = 0; // sikre sig at byte er 0000 0000
	writeBuffer[1] = 0;
	writeBuffer[0] = writeBuffer[0] | 1; // byte 0 skal være 0000 0001
	writeBuffer[1] = writeBuffer[1] | 128; // byte 1 most significant bit vælger mode
	writeBuffer[1] = writeBuffer[1] | (pin << 4); // 1xxx 0000 hvor x er kanal
	
	// start komunication
	XSpiPs_PolledTransfer(&SpiInstance, writeBuffer, readBuffer, 3);

	// vent for for at spi er klar igen (taget fra Martin)
	int a;
	while (a < 500000) { //Taras v�rdi: 50000000
		a++;
	}
	int value = 0;
	value = (value | ((readBuffer[1] & 3) << 8)) | readBuffer[2];
	return value;
}

