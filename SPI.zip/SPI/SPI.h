/*
	@Project: Line zapper
	@Function: SPI setup and reader
	@Autor: Martin Lund Djurhuus
	@Universty: Technical University of Denmark - DTU
	@Date: 18 January 2017
*/

#include "xil_types.h"
#include "xparameters.h"
#include <stdio.h>
#include "xspips.h"
#include "xplatform_info.h"
#include "xil_printf.h"

#define SPI_HEADER 1 //tell 

#define SPI_DEVICE_ID XPAR_PS7_SPI_1_DEVICE_ID // id for spi Input


void SPI_setup();
int SPI_read(int pin);
